# 自助點餐機伺服器啟動腳本 (PowerShell)
Set-Location -LiteralPath $PSScriptRoot
$host.UI.RawUI.WindowTitle = "Kiosk Server"

$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

$python = if (Test-Path "Y:\mini\python\python.exe") { "Y:\mini\python\python.exe" } else { "python" }

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  🍱 美味小站 - 自助點餐機 伺服器啟動程式" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "正在開啟瀏覽器: http://localhost:8000" -ForegroundColor Green

Start-Process "http://localhost:8000"
& $python server.py
