@echo off
cd /d "%~dp0"
title Kiosk Server

set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"

set "PYTHON_EXE=Y:\mini\python\python.exe"
if not exist "%PYTHON_EXE%" (
    set "PYTHON_EXE=python"
)

echo ========================================================
echo   Kiosk Order System - Starting Server...
echo ========================================================
echo.
echo Opening browser: http://localhost:8000
start http://localhost:8000

"%PYTHON_EXE%" server.py
if errorlevel 1 (
    echo.
    echo Server stopped with error.
    pause
)
