"""
點餐機後端伺服器 (Kiosk Backend Server)
使用 FastAPI + Uvicorn 提供 RESTful API 與前端靜態網頁服務
資料持久化儲存於本機 kiosk.json
"""

import json
import os
import sys
import io
import csv
import time
import socket
import threading
from typing import Optional, List, Dict, Any
from pathlib import Path

# 強制 Windows 主控台標準輸出為 UTF-8，防止編碼異常
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, Response, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# 基礎路徑與資料檔
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "kiosk.json"
HTML_FILE = BASE_DIR / "index.html"
# 若使用者已命名為 kiosk.html，則優先偵測
if not HTML_FILE.exists() and (BASE_DIR / "kiosk.html").exists():
    HTML_FILE = BASE_DIR / "kiosk.html"

file_lock = threading.Lock()

app = FastAPI(
    title="用餐小站點餐機 API",
    description="提供自助點餐機之菜單管理、即時訂單收單、店家後台管理與營收統計功能",
    version="2.0.0"
)

# 允許跨域請求 (支援手機、平板或跨 port 測試)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_local_ip() -> str:
    """取得本機區域網路 IP，方便手機/平板掃描連線"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip


def load_db() -> Dict[str, Any]:
    """從 kiosk.json 讀取最新狀態"""
    with file_lock:
        if not DATA_FILE.exists():
            default_data = {
                "version": "2.0.0",
                "updatedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "storeName": "美味小站",
                "pin": "1234",
                "nextTicket": 1,
                "menu": [],
                "orders": []
            }
            save_db(default_data)
            return default_data
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[警告] 讀取 kiosk.json 失敗: {e}")
            raise HTTPException(status_code=500, detail="讀取資料庫失敗")


def save_db(data: Dict[str, Any]) -> None:
    """寫入 kiosk.json (含線程鎖防止競態條件)"""
    with file_lock:
        data["updatedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        temp_file = DATA_FILE.with_suffix(".tmp")
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        temp_file.replace(DATA_FILE)


# ==============================================================================
# Pydantic 驗證模型
# ==============================================================================
class OrderItem(BaseModel):
    id: str
    name: str
    price: float
    quantity: int

class CreateOrderRequest(BaseModel):
    diningMode: str  # 'dine-in' | 'take-out'
    tableNo: Optional[str] = None
    phoneTail: Optional[str] = None
    note: Optional[str] = ""
    items: List[OrderItem]
    total: float

class UpdateOrderRequest(BaseModel):
    status: Optional[str] = None  # 'pending' | 'completed'
    note: Optional[str] = None

class MenuItem(BaseModel):
    id: Optional[str] = None
    name: str
    price: float
    category: Optional[str] = "主食"
    enabled: Optional[bool] = True

class StoreSettingsRequest(BaseModel):
    storeName: str
    pin: str


# ==============================================================================
# RESTful API 端點
# ==============================================================================
@app.get("/api/data", summary="取得所有資料 (店名、菜單、訂單等)")
def get_all_data():
    return load_db()


@app.post("/api/order", summary="顧客送出訂單")
def create_order(req: CreateOrderRequest):
    if not req.items:
        raise HTTPException(status_code=400, detail="購物車不可為空")

    db = load_db()
    current_ticket = db.get("nextTicket", 1)
    ticket_str = f"{current_ticket:03d}"
    order_id = f"ord_{int(time.time() * 1000)}_{os.urandom(2).hex()}"

    new_order = {
        "id": order_id,
        "ticket": ticket_str,
        "diningMode": req.diningMode,
        "tableNo": req.tableNo if req.diningMode == "dine-in" else None,
        "phoneTail": req.phoneTail if req.diningMode == "take-out" else None,
        "note": req.note or "",
        "items": [item.model_dump() for item in req.items],
        "total": req.total,
        "status": "pending",
        "createdAt": int(time.time() * 1000)
    }

    if "orders" not in db:
        db["orders"] = []
    db["orders"].append(new_order)
    db["nextTicket"] = current_ticket + 1

    save_db(db)
    print(f"[新訂單] 取號 #{ticket_str} | 金額: NT${req.total:.0f} | 模式: {req.diningMode}")
    return new_order


@app.patch("/api/orders/{order_id}", summary="修改訂單狀態 (出餐完成/重設待處理)")
def update_order(order_id: str, req: UpdateOrderRequest):
    db = load_db()
    orders = db.get("orders", [])
    target = None
    for o in orders:
        if o.get("id") == order_id:
            target = o
            break

    if not target:
        raise HTTPException(status_code=404, detail="找不到該訂單")

    if req.status is not None:
        target["status"] = req.status
    if req.note is not None:
        target["note"] = req.note

    save_db(db)
    return target


@app.delete("/api/orders/{order_id}", summary="刪除指定訂單")
def delete_order(order_id: str):
    db = load_db()
    orders = db.get("orders", [])
    new_orders = [o for o in orders if o.get("id") != order_id]

    if len(new_orders) == len(orders):
        raise HTTPException(status_code=404, detail="找不到欲刪除的訂單")

    db["orders"] = new_orders
    save_db(db)
    return {"success": True, "message": f"訂單 {order_id} 已刪除"}


@app.post("/api/orders/reset", summary="重置今日所有訂單與號碼計數")
def reset_orders():
    db = load_db()
    db["orders"] = []
    db["nextTicket"] = 1
    save_db(db)
    print("[系統] 已清空今日所有訂單紀錄")
    return {"success": True, "message": "今日訂單已重置"}


@app.post("/api/menu", summary="新增或編輯菜單餐點")
def save_menu_item(item: MenuItem):
    db = load_db()
    menu = db.get("menu", [])

    if item.id:
        # 編輯現有項目
        found = False
        for i, m in enumerate(menu):
            if m.get("id") == item.id:
                menu[i] = item.model_dump()
                found = True
                break
        if not found:
            menu.append(item.model_dump())
    else:
        # 新增項目
        item_id = f"item_{int(time.time() * 1000)}"
        new_item = item.model_dump()
        new_item["id"] = item_id
        menu.append(new_item)
        item = MenuItem(**new_item)

    db["menu"] = menu
    save_db(db)
    return {"success": True, "item": item.model_dump()}


@app.delete("/api/menu/{item_id}", summary="刪除菜單項目")
def delete_menu_item(item_id: str):
    db = load_db()
    menu = db.get("menu", [])
    new_menu = [m for m in menu if m.get("id") != item_id]

    if len(new_menu) == len(menu):
        raise HTTPException(status_code=404, detail="找不到該餐點")

    db["menu"] = new_menu
    save_db(db)
    return {"success": True, "message": "餐點已刪除"}


@app.post("/api/settings", summary="儲存店名與管理 PIN 碼")
def update_settings(req: StoreSettingsRequest):
    db = load_db()
    db["storeName"] = req.storeName
    db["pin"] = req.pin
    save_db(db)
    print(f"[設定] 店名更新為「{req.storeName}」")
    return {"success": True, "message": "設定已更新"}


@app.get("/api/export/csv", summary="匯出今日營收訂單 CSV")
def export_csv():
    db = load_db()
    orders = db.get("orders", [])

    output = io.StringIO()
    # 寫入 UTF-8 BOM 避免 Excel 開啟亂碼
    output.write("\ufeff")
    writer = csv.writer(output)
    writer.writerow(["訂單號", "用餐型態", "桌號或電話", "餐點內容", "備註", "總金額", "出餐狀態", "建立時間"])

    for o in orders:
        dining_type = "內用" if o.get("diningMode") == "dine-in" else "外帶"
        ident = o.get("tableNo") if o.get("diningMode") == "dine-in" else o.get("phoneTail")
        items_str = "; ".join([f"{item.get('name')}x{item.get('quantity')}" for item in o.get("items", [])])
        created_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(o.get("createdAt", 0) / 1000))

        writer.writerow([
            o.get("ticket"),
            dining_type,
            ident or "",
            items_str,
            o.get("note", ""),
            o.get("total", 0),
            "已完成" if o.get("status") == "completed" else "製作中",
            created_time
        ])

    today_str = time.strftime("%Y%m%d")
    filename = f"kiosk_orders_{today_str}.csv"
    return Response(
        content=output.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )


# ==============================================================================
# 前端靜態頁面服務
# ==============================================================================
@app.get("/", response_class=HTMLResponse, summary="前端點餐主頁面")
def serve_index():
    # 優先找 index.html，其次 kiosk.html
    for fname in ["index.html", "kiosk.html"]:
        p = BASE_DIR / fname
        if p.exists():
            return HTMLResponse(content=p.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>找不到前端 HTML 檔案 (index.html 或 kiosk.html)</h1>", status_code=404)


@app.get("/{filename}", summary="靜態檔案 (kiosk.json、kiosk.html 等)")
def serve_static(filename: str):
    file_path = BASE_DIR / filename
    if file_path.exists() and file_path.is_file():
        # 如果是 json 檔案
        if filename.endswith(".json"):
            return JSONResponse(content=json.loads(file_path.read_text(encoding="utf-8")))
        return FileResponse(file_path)
    raise HTTPException(status_code=404, detail="檔案不存在")


# ==============================================================================
# 伺服器啟動入口
# ==============================================================================
def main():
    port = 8000
    host = "0.0.0.0"
    local_ip = get_local_ip()

    print("\n" + "=" * 65)
    print(" 🍱  美味小站 - 自助點餐機 伺服器啟動中...")
    print("=" * 65)
    print(f" ▶ 本機電腦瀏覽:    http://localhost:{port}")
    print(f" ▶ 手機/平板連線:   http://{local_ip}:{port}")
    print(f" ▶ API 線上文件:    http://localhost:{port}/docs")
    print(f" ▶ 資料儲存檔案:    {DATA_FILE}")
    print("=" * 65)
    print(" [提示] 同一 Wi-Fi 下的手機或平板，直接開啟「手機/平板連線」網址即可點餐！")
    print(" 按下 Ctrl+C 可停止伺服器\n")

    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
